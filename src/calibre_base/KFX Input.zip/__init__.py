#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import, print_function)

import argparse
import cgi
import os
import platform
import StringIO
import traceback

from calibre.constants import (config_dir, get_version)
from calibre.customize.conversion import (InputFormatPlugin, OptionRecommendation)
from calibre.ebooks import (BOOK_EXTENSIONS, DRMError)
from calibre.ebooks.conversion import ConversionUserFeedBack
from calibre.ebooks.conversion.plugins.epub_input import EPUBInput
from calibre.ebooks.metadata.opf2 import OPF
from calibre.utils.logging import Log


__license__   = "GPL v3"
__copyright__ = "2018, John Howell <jhowell@acm.org>"



class KFXInput(InputFormatPlugin):
    name = "KFX Input"
    author = "jhowell"
    file_types  = {"azw8", "kfx", "kfx-zip", "kpf"}
    version = (1, 3, 0)
    minimum_calibre_version = (2, 0, 0)
    supported_platforms = ["windows", "osx", "linux"]
    description = "Convert from Amazon KFX format"

    options = {
        OptionRecommendation(name="allow_conversion_with_errors", recommended_value=False,
            help="Allow conversion to proceed even if the KFX book contains unexpected or incorrect data "
            "that may not convert properly. If this option is selected it is recommend that the log of each "
            "conversion be checked for error messages."),
    }

    recommendations = EPUBInput.recommendations


    def __init__(self, *args, **kwargs):
        self.cli = False
        InputFormatPlugin.__init__(self, *args, **kwargs)

        self.epub_input_plugin = EPUBInput(*args, **kwargs)

        self.resources = self.load_resources(["kfx.png", "plugin_widget.py"])

        self.load_kfx_icon()
        self.init_embedded_plugins()

        for file_type in self.file_types:
            if file_type not in BOOK_EXTENSIONS:
                BOOK_EXTENSIONS.append(file_type)   # show files of this type in add book format dialog


    def load_kfx_icon(self):
        # calibre does not include an icon for KFX format

        filename = os.path.join(config_dir, "resources", "images", "mimetypes", "kfx.png")
        if not os.path.isfile(filename):
            try:
                os.makedirs(os.path.dirname(filename))
            except:
                pass

            try:
                with open(filename, "wb") as f:
                    f.write(self.resources["kfx.png"])
            except:
                print("Failed to create KFX icon file")
                traceback.print_exc()


    def gui_configuration_widget(self, parent, get_option_by_name, get_option_help, db, book_id=None):
        from calibre_plugins.kfx_input.kfx_input import PluginWidget
        return PluginWidget(parent, get_option_by_name, get_option_help, db, book_id)


    def convert(self, stream, options, file_ext, log, accelerators):
        from calibre_plugins.kfx_input.kfxlib import (KFXDRMError, file_write_binary)

        self.report_version(log)

        if (not hasattr(stream, "name")) or (not stream.name.endswith("." + file_ext)):
            self.log.info("Creating temporary file for %s conversion" % file_ext)
            stream.seek(0)
            filename = self.temporary_file("." + file_ext).name
            file_write_binary(filename, stream.read())
            stream = filename

        try:
            epub_data = self.convert_from_kfx(JobLog(log), stream, options.allow_conversion_with_errors)
        except KFXDRMError:
            traceback.print_exc()
            raise DRMError('This book has DRM!')
        except Exception as e:
            traceback.print_exc()
            raise ConversionUserFeedBack("KFX conversion failed",
                    "<b>Cannot convert %s</b><br><br>%s" % (clean_msg(self.get_title(options)), clean_msg(unicode(e))),
                    level="error")

        log.info("Successfully converted %s to EPUB -- running EPUB input plugin" % file_ext)

        result = self.epub_input_plugin.convert(StringIO.StringIO(epub_data), options, "epub", log, accelerators)

        log.info("KFX Input plugin processing complete")

        return result


    def get_title(self, options):
        if options.title:
            return options.title

        if options.read_metadata_from_opf:
            try:
                opf_path = os.path.abspath(options.read_metadata_from_opf)
                mi = OPF(open(opf_path, 'rb'), os.path.dirname(opf_path)).to_book_metadata()
                return mi.title
            except:
                return ""


    def cli_main(self, argv):
        from calibre_plugins.kfx_input.kfxlib import file_write_binary

        self.cli = True
        log = JobLog(Log())
        self.report_version(log)
        log.info("")

        allowed_exts = [".%s" % e for e in sorted(list(self.file_types))]
        ext_choices = ", ".join(allowed_exts[:-1] + ["or " + allowed_exts[-1]])

        parser = argparse.ArgumentParser(prog='calibre-debug -r "KFX Input" --', description="Convert e-book from KFX to EPUB")
        parser.add_argument("infile", help="Pathname of the %s file to be converted to .epub" % ext_choices)
        parser.add_argument("outfile", nargs="?", help="Optional pathname of the resulting .epub file")
        parser.add_argument("-e", "--epubversion", action="store", help="EPUB version to generate: 2.0, 3.0, 3.1")
        args = parser.parse_args(argv[1:])     # argv provided by calibre is unicode

        input_filename = args.infile
        intype = os.path.splitext(input_filename)[1]

        if not os.path.isfile(input_filename):
            raise Exception("Input file does not exist: %s" % input_filename)

        if args.outfile:
            output_filename = args.outfile
        else:
            output_filename = os.path.join(os.path.dirname(input_filename), os.path.splitext(os.path.basename(input_filename))[0] + ".epub")

        if not output_filename.endswith(".epub"):
            raise Exception("Output file must have .epub extension")

        epub_version = args.epubversion or "2.0"

        if epub_version not in ["2.0", "3.0", "3.1"]:
            raise Exception("EPUB version must be 2.0, 3.0, or 3.1")

        if intype in allowed_exts:
            file_write_binary(output_filename, self.convert_from_kfx(log, input_filename, True, epub_version=epub_version))
            log.info("Converted books saved to %s" % output_filename)
        else:
            raise Exception("Input file must be %s" % ext_choices)


    def report_version(self, log):
        log.info("Software versions: %s %s, calibre %s, %s" % (self.name, ".".join([unicode(v) for v in self.version]),
                get_version(), platform.platform()))
        log.info("KFX Input plugin help is available at https://www.mobileread.com/forums/showthread.php?t=291290")


    def convert_from_kfx(self, log, file, allow_conversion_with_errors, epub_version="2.0"):
        from calibre_plugins.kfx_input.kfxlib import (YJ_Book)

        if isinstance(file, unicode) or isinstance(file, str):
            filename = file
        elif hasattr(file, "name"):
            filename = file.name
        else:
            filename = "unknown"

        log.info("Converting %s" % filename)

        yj_book = YJ_Book(file, log)
        epub_data = yj_book.convert_to_epub(epub_version=epub_version)

        if log.errors and not allow_conversion_with_errors:
            raise Exception("\n".join(log.errors))

        return epub_data


    def init_embedded_plugins(self):
        from calibre.customize.ui import (_initialized_plugins, reread_filetype_plugins, reread_metadata_plugins)
        from calibre_plugins.kfx_input.gather_filetype import GatherKFXZIPFileTypePlugin
        from calibre_plugins.kfx_input.package_filetype import PackageKFXFileTypePlugin
        from calibre_plugins.kfx_input.metadata_reader import KFXMetadataReader

        def init_pi(pi_type):
            for pi in _initialized_plugins:
                if isinstance(pi, pi_type):
                    return False    # already initialized
            else:
                pi_type.version = self.version
                plugin = pi_type(self.plugin_path)
                _initialized_plugins.append(plugin)
                plugin.initialize()
                return True

        init1 = init_pi(GatherKFXZIPFileTypePlugin)
        init2 = init_pi(PackageKFXFileTypePlugin)

        if init1 or init2:
            reread_filetype_plugins()

        if init_pi(KFXMetadataReader):
            reread_metadata_plugins()


def clean_msg(msg):
    # remove chars that cause problems for ConversionUserFeedBack
    return cgi.escape(msg).replace("%","%%").replace("{","(").replace("}",")")


class JobLog(object):
    '''
    Logger that also collects errors and warnings for presentation in a job summary.
    '''

    def __init__(self, logger):
        self.logger = logger
        self.errors = []
        self.warnings = []

    def debug(self, msg):
        self.logger.debug(msg)

    def info(self, msg):
        self.logger.info(msg)

    def warn(self, msg):
        self.warnings.append(msg)
        self.logger.warn("WARNING: %s" % msg)

    def warning(self, desc):
        self.warn(desc)

    def error(self, msg):
        self.errors.append(msg)
        self.logger.error("ERROR: %s" % msg)

    def exception(self, msg):
        self.errors.append("EXCEPTION: %s" % msg)
        self.logger.exception("EXCEPTION: %s" % msg)
