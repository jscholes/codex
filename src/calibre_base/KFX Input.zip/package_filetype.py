from __future__ import (unicode_literals, division, absolute_import, print_function)

from calibre.customize import FileTypePlugin

__license__   = "GPL v3"
__copyright__ = "2018, John Howell <jhowell@acm.org>"


class PackageKFXFileTypePlugin(FileTypePlugin):
    name                = "Package KFX File Type (from KFX Input)"
    description         = "Import Amazon KFX format Pt 2 - package a KFX-ZIP book into monolithic KFX"
    supported_platforms = ["windows", "osx", "linux"]
    author              = "jhowell"
    file_types          = {"azw", "azw8", "kfx", "kfx-zip"}     # original type - any type that could turn into kfx-zip
    on_import           = True
    priority            = 200
    minimum_calibre_version = (2, 0, 0)


    def run(self, path_to_ebook):
        if path_to_ebook.endswith(".kfx-zip"):
            return self.run_kfx(path_to_ebook)

        return path_to_ebook


    def run_kfx(self, path_to_ebook):
        from calibre.utils.logging import Log
        from calibre_plugins.kfx_input.kfxlib import (file_write_binary, YJ_Book)

        log = Log()

        log.info("%s %s: Packaging %s" % (self.name, ".".join([unicode(i) for i in self.version]), path_to_ebook))

        kfx_data = YJ_Book(path_to_ebook, log).convert_to_single_kfx()

        outfile = self.temporary_file(".kfx").name
        file_write_binary(outfile, kfx_data)

        log.info("KFX Input: Imported as %s" % outfile)
        return outfile
