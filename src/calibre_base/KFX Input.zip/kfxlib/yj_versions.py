from __future__ import (unicode_literals, division, absolute_import, print_function)

ANY = None
TF = {False,  True}

KNOWN_GENERATORS = {

    ("2.16", "PackageVersion:YJReaderSDK-1.0.824.0 Month-Day:04-09", "489"),

    ("3.42.1.0", "PackageVersion:YJReaderSDK-1.0.2044.4 Month-Day:10-28", "609"),

    ("6.11.1.2", "PackageVersion:YJReaderSDK-1.0.2467.8 Month-Day:07-14", "620"),

    ("6.11.1.2", "PackageVersion:YJReaderSDK-1.0.2539.3 Month-Day:03-17", "620"),

    ("6.20.1.0", "PackageVersion:YJReaderSDK-1.0.2685.4 Month-Day:05-19", "626"),

    ("6.24.1.0", "PackageVersion:YJReaderSDK-1.1.67.2 Month-Day:06-18", "609"),
    ("6.24.1.0", "PackageVersion:YJReaderSDK-1.1.67.2 Month-Day:06-18", "626"),
    ("6.24.1.0", "PackageVersion:YJReaderSDK-1.1.67.2 Month-Day:06-18", "627"),

    ("6.28.1.0", "PackageVersion:YJReaderSDK-1.1.67.4 Month-Day:07-14", "609"),
    ("6.28.1.0", "PackageVersion:YJReaderSDK-1.1.67.4 Month-Day:07-14", "626"),
    ("6.28.1.0", "PackageVersion:YJReaderSDK-1.1.67.4 Month-Day:07-14", "627"),
    ("6.28.1.0", "PackageVersion:YJReaderSDK-1.1.67.4 Month-Day:07-14", "634"),

    ("6.28.2.0", "PackageVersion:YJReaderSDK-1.1.147.0 Month-Day:09-10", "626"),
    ("6.28.2.0", "PackageVersion:YJReaderSDK-1.1.147.0 Month-Day:09-10", "627"),
    ("6.28.2.0", "PackageVersion:YJReaderSDK-1.1.147.0 Month-Day:09-10", "634"),

    ("7.38.1.0", "PackageVersion:YJReaderSDK-1.2.173.0 Month-Day:09-20", "609"),
    ("7.38.1.0", "PackageVersion:YJReaderSDK-1.2.173.0 Month-Day:09-20", "627"),
    ("7.38.1.0", "PackageVersion:YJReaderSDK-1.2.173.0 Month-Day:09-20", "634"),
    ("7.38.1.0", "PackageVersion:YJReaderSDK-1.2.173.0 Month-Day:09-20", "652"),

    ("7.45.1.0", "PackageVersion:YJReaderSDK-1.4.23.0 Month-Day:11-23", "609"),
    ("7.45.1.0", "PackageVersion:YJReaderSDK-1.4.23.0 Month-Day:11-23", "634"),
    ("7.45.1.0", "PackageVersion:YJReaderSDK-1.4.23.0 Month-Day:11-23", "662"),

    (ANY, "", "662"),
    (ANY, "KPR", "662"),
    (ANY, "KPR-3.0.0", "662"),

    (ANY, "KTC-1.11.539.0", "662"),

    (ANY, "KPR-3.1.0", "662"),

    (ANY, "KPR-3.2.0", "662"),

    (ANY, "KPR-3.3.0", "662"),

    (ANY, "KTC-1.12.11.0", "662"),

    ("7.58.1.0", "PackageVersion:YJReaderSDK-1.5.116.0 Month-Day:02-25", "667"),

    ("7.66.1.0", "PackageVersion:YJReaderSDK-1.5.185.0 Month-Day:04-13", "667"),

    ("7.66.1.0", "PackageVersion:YJReaderSDK-1.5.195.0 Month-Day:04-20", "634"),
    ("7.66.1.0", "PackageVersion:YJReaderSDK-1.5.195.0 Month-Day:04-20", "652"),
    ("7.66.1.0", "PackageVersion:YJReaderSDK-1.5.195.0 Month-Day:04-20", "662"),
    ("7.66.1.0", "PackageVersion:YJReaderSDK-1.5.195.0 Month-Day:04-20", "667"),
    ("7.66.1.0", "PackageVersion:YJReaderSDK-1.5.195.0 Month-Day:04-20", "668"),

    (ANY, "KPR-3.4.0", "667"),

    (ANY, "KPR-3.5.0", "667"),

    (ANY, "KTC-1.13.7.0", "662"),

    (ANY, "KPR-3.6.0", "673"),

    ("7.91.1.0", "PackageVersion:YJReaderSDK-1.5.566.6 Month-Day:11-03", "668"),

    ("7.91.1.0", "PackageVersion:YJReaderSDK-1.5.595.1 Month-Day:11-30", "634"),
    ("7.91.1.0", "PackageVersion:YJReaderSDK-1.5.595.1 Month-Day:11-30", "662"),
    ("7.91.1.0", "PackageVersion:YJReaderSDK-1.5.595.1 Month-Day:11-30", "668"),
    ("7.91.1.0", "PackageVersion:YJReaderSDK-1.5.595.1 Month-Day:11-30", "673"),

    (ANY, "KPR-3.7.0", "681"),

    (ANY, "KPR-3.7.1", "681"),

    (ANY, "KPR-3.8.0", "693"),

    (ANY, "KC-0.93.187.0", "695"),
    (ANY, "KTC-1.0.11.1", "695"),
    (ANY, "KC-0.93.187.0", "695.27"),

    (ANY, "KPR-3.9.0", "695"),

    ("7.111.1.1", "PackageVersion:YJReaderSDK-1.6.444.0 Month-Day:02-27", "673"),
    ("7.111.1.1", "PackageVersion:YJReaderSDK-1.6.444.0 Month-Day:02-27", "696"),

    ("7.111.1.1", "PackageVersion:YJReaderSDK-1.6.444.5 Month-Day:03-20", "696"),

    (ANY, "KTC-1.0.11.1", "696"),
    (ANY, "KC-0.94.32.0", "696.27"),

    (ANY, "KTC-1.0.11.1", "696"),
    (ANY, "KC-0.96.4.0", "696.30"),

    (ANY, "KPR-3.10.1", "696"),

    ("7.121.3.0", "PackageVersion:YJReaderSDK-1.6.444.18 Month-Day:05-02", "634"),
    ("7.121.3.0", "PackageVersion:YJReaderSDK-1.6.444.18 Month-Day:05-02", "673"),
    ("7.121.3.0", "PackageVersion:YJReaderSDK-1.6.444.18 Month-Day:05-02", "697"),

    (ANY, "KPR-3.11.0", "697"),

    ("7.125.1.0", "PackageVersion:YJReaderSDK-1.6.444.24 Month-Day:06-01", "696"),
    ("7.125.1.0", "PackageVersion:YJReaderSDK-1.6.444.24 Month-Day:06-01", "697"),
    ("7.125.1.0", "PackageVersion:YJReaderSDK-1.6.444.24 Month-Day:06-01", "668"),
    ("7.125.1.0", "PackageVersion:YJReaderSDK-1.6.444.24 Month-Day:06-01", "700"),

    (ANY, "KTC-1.0.11.1", "700"),
    (ANY, "KC-0.97.79.3", "700.30"),

    ("7.125.1.0", "PackageVersion:YJReaderSDK-1.6.444.33 Month-Day:06-16", "700"),

    (ANY, "KPR-3.12.0", "700"),

    ("7.131.2.0", "PackageVersion:YJReaderSDK-1.6.444.36 Month-Day:07-10", "667"),
    ("7.131.2.0", "PackageVersion:YJReaderSDK-1.6.444.36 Month-Day:07-10", "697"),
    ("7.131.2.0", "PackageVersion:YJReaderSDK-1.6.444.36 Month-Day:07-10", "700"),

    (ANY, "KTC-1.0.11.1", "700"),
    (ANY, "KC-0.98.260.0", "700.28"),
    (ANY, "KC-0.98.260.0", "700"),

    (ANY, "KTC-1.0.11.1", "700"),
    (ANY, "KC-0.98.315.0", "700.28"),
    (ANY, "KC-0.98.315.0", "700"),

    (ANY, "KPR-3.13.0", "700"),

    (ANY, "KTC-1.0.11.1", "700"),
    (ANY, "KC-0.99.28.0", "700.28"),
    (ANY, "KC-0.99.28.0", "700"),

    (ANY, "KTC-1.0.11.1", "701"),
    (ANY, "KC-0.101.1.0", "701.28"),
    (ANY, "KC-0.101.1.0", "701"),

    (ANY, "KPR-3.14.0", "705"),

    (ANY, "KTC-1.0.11.1", "701"),
    (ANY, "KC-0.102.0.0", "701.28"),
    (ANY, "KC-0.102.0.0", "701"),

    (ANY, "KPR-3.15.0", "705"),

    (ANY, "KTC-1.0.11.1", "701"),
    (ANY, "KC-0.103.0.0", "701.28"),
    (ANY, "KC-0.103.0.0", "701"),

    (ANY, "KTC-1.0.11.1", "701"),
    (ANY, "KC-1.0.319.0", "701.28"),
    (ANY, "KC-1.0.319.0", "701"),

    (ANY, "KPR-3.16.0", "705"),

    ("7.135.2.0", "PackageVersion:YJReaderSDK-1.6.1034.2 Month-Day:08-23", "705"),

    ("7.135.2.0", "PackageVersion:YJReaderSDK-1.6.1034.13 Month-Day:10-09", "673"),
    ("7.135.2.0", "PackageVersion:YJReaderSDK-1.6.1034.13 Month-Day:10-09", "700"),
    ("7.135.2.0", "PackageVersion:YJReaderSDK-1.6.1034.13 Month-Day:10-09", "705"),
    ("7.135.2.0", "PackageVersion:YJReaderSDK-1.6.1034.13 Month-Day:10-09", "716"),

    ("7.135.2.0", "PackageVersion:YJReaderSDK-1.6.1034.17 Month-Day:11-06", "716"),

    (ANY, "KPR-3.17.0", "716"),
    (ANY, "KPR-3.17.0", "716.2"),
    (ANY, "KPR-3.17.0", "716.3"),

    (ANY, "", "697.4"),

    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.1034.59 Month-Day:12-06", "668"),
    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.1034.59 Month-Day:12-06", "716"),

    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.1034.62 Month-Day:12-21", "716"),

    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.1034.72 Month-Day:01-04", "716"),

    (ANY, "KPR-3.17.1", "716"),
    (ANY, "KPR-3.17.1", "716.2"),
    (ANY, "KPR-3.17.1", "716.3"),

    (ANY, "KTC-1.0.11.1", "716"),
    (ANY, "KC-1.3.30.0", "716"),

    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.1938.0 Month-Day:01-29", "716"),
    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.1938.0 Month-Day:01-29", "748"),

    (ANY, "KPR-3.20.0", "716"),
    (ANY, "KPR-3.20.0", "716.2"),
    (ANY, "KPR-3.20.0", "716.3"),

    (ANY, "KPR-3.20.1", "716"),
    (ANY, "KPR-3.20.1", "716.2"),
    (ANY, "KPR-3.20.1", "716.3"),

    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.2071.0 Month-Day:02-12", "748"),

    (ANY, "KC-1.4.200067.0", "716"),
    (ANY, "KC-1.5.60.0", "716"),

    (ANY, "KPR-3.21.0", "716"),
    (ANY, "KPR-3.21.0", "716.2"),
    (ANY, "KPR-3.21.0", "716.3"),

    ("7.149.1.0", "PackageVersion:YJReaderSDK-1.6.200363.0 Month-Day:03-19", "748"),
}

GENERIC_CREATOR_VERSIONS = {

    ("YJConversionTools", "2.15.0"),
    ("KTC", "1.0.11.1"),
    }

KNOWN_FEATURES = {

    "format_capabilities": {
        "kfxgen.pidMapWithOffset": {1},
        "kfxgen.positionMaps": {2},
        "kfxgen.textBlock": {1},

        "db.schema": {1},
        },

    "SDK.Marker": {
        "CanonicalFormat": {
            1,
            2,
            },
        },

    "com.amazon.yjconversion": {
        "ar-reflow-language": {1},
        "cn-reflow-language": {1},
        "indic-reflow-language": {1},
        "jp-reflow-language": {1},
        "reflow-language": {3},

        "reflow-section-size": ANY,

        "reflow-style": {
            1,
            2,
            3,
            4,
            5,
            6,
            7,

            9,
            10,

            },

        "yj_audio": {1},

        "yj_custom_word_iterator": {1},

        "yj_dictionary": {
            1,
            2,
            },

        "yj_double_page_spread": {1},

        "yj_facing_page": {1},

        "yj_fixed_layout": {1},

        "yj_graphical_highlights": {1},

        "yj_hdv": {1},

        "yj_interactive_image": {1},

        "yj_jpegxr_sd": {1},

        "yj_jpg_rst_marker_present": {1},

        "yj_non_pdf_fixed_layout": {2},

        "yj_pdf_links": {1},

        "yj_pdf_support": {1},

        "yj_publisher_panels": {2},

        "yj_table": {
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            },

        "yj_table_viewer": {
            1,
            2,
            },

        "yj_textbook": {1},

        "yj_thumbnails_present": {1},

        "yj_video": {1},

        "yj.conditional_structure": {1},

        "yj.illustrated_layout": {1},

        },
    }

KNOWN_METADATA = {

    "kindle_audit_metadata": {

        "file_creator": {
            "YJConversionTools",
            "FLYP",
            "KTC",
            "KC",
            "KPR",
        },

        "creator_version": {
            "2.15.0",

            "2.0.0.1",

            "1.5.14.0",
            "1.8.1.0",
            "1.9.2.0",
            "1.11.399.0",
            "1.11.539.0",
            "1.12.11.0",
            "1.13.7.0",

            "0.93.187.0",
            "0.94.32.0",
            "0.95.8.0",
            "0.96.4.0",
            "0.97.79.3",
            "0.98.260.0",
            "0.98.315.0",
            "0.99.28.0",
            "0.101.1.0",
            "1.2.83.0",
            "1.3.30.0",
            "1.4.200067.0",
            "1.5.60.0",

            "3.8.0",
            "3.9.0",
            "3.10.1",
            "3.11.0",
            "3.12.0",
            "3.13.0",
            "3.14.0",
            "3.15.0",
            "3.16.0",
            "3.17.0",
            "3.17.1",
            "3.20.0",
            "3.20.1",
            "3.21.0",
            }

    },

    "kindle_capability_metadata": {

        "yj_fixed_layout": {1},

        "continuous_popup_progression": {0},
        "yj_double_page_spread": {1},
        "yj_publisher_panels": {1},
        "yj_facing_page": {1},

        "graphical_highlights": {1},
        "yj_textbook": {1},

        "yj_has_animations": {1},
        "yj_illustrated_layout": {1},

        },

    "kindle_ebook_metadata": {
        "book_orientation_lock": {
            "landscape",
            "portrait",
            "none"
            },
        "multipage_selection": {"disabled"},
        "selection": {"enabled"},
        "user_visible_labeling": {"page_exclusive"},

        },

    "kindle_title_metadata": {

        "cde_content_type": {
            "EBOK",
            "EBSP",

            "MAGZ",

            "PDOC",

            },

        "ASIN": ANY,
        "asset_id": ANY,
        "author": ANY,
        "author_pronunciation": ANY,
        "book_id": ANY,
        "content_id": ANY,
        "description": ANY,
        "cover_image": ANY,
        "dictionary_lookup": ANY,
        "imprint_pronunciation": ANY,
        "is_dictionary": {True},
        "is_sample": TF,
        "issue_date": ANY,
        "language": ANY,
        "override_kindle_font": TF,
        "publisher": ANY,
        "title": ANY,
        "title_pronunciation": ANY,

        },

    "metadata": {
        "ASIN": ANY,
        "asset_id": ANY,
        "author": ANY,
        "binding_direction": {"binding_direction_left"},
        "cde_content_type": {
            "EBOK",
            "MAGZ",
            "PDOC",
            },
        "cover_image": ANY,
        "cover_page": ANY,
        "doc_sym_publication_id": ANY,
        "description": ANY,
        "issue_date": ANY,
        "language": ANY,
        "orientation": {"portrait", "landscape"},
        "parent_asin": ANY,
        "publisher": ANY,
        "reading_orders": ANY,
        "support_landscape": TF,
        "support_portrait": TF,
        "target_NarrowDimension": ANY,
        "target_WideDimension": ANY,
        "title": ANY,
        "volume_label": ANY,
        }
    }

KNOWN_AUXILIARY_METADATA = {
    "auxData_resource_list": ANY,
    "base_line": ANY,
    "filename.opf": ANY,
    "IsSymNameBased": {True},
    "IS_TARGET_SECTION": {True},
    "kSectionContainsAVI": {True},
    "links_extracted": {True},
    "link_from_text": TF,
    "location": ANY,
    "mime": {"Audio", "Figure"},
    "ModifiedContentInfo": ANY,
    "modified_time": ANY,
    "most-common-computed-style": ANY,
    "namespace": {"KindleConversion"},
    "num-dual-covers-removed": {1},
    "page_rotation": {0},
    "plugin_group_list": ANY,
    "resizable_plugin": {False},
    "resource_stream": ANY,
    "size": ANY,
    "SourceIdContentInfo": ANY,
    "target": ANY,
    "text_baseline": ANY,
    "text_ext": {1},
    "type": {"resource"},
    "yj.dictionary.first_head_word": ANY,
    "yj.dictionary.inflection_rules": ANY,
    }

def is_known_generator(generator):
    return generator in KNOWN_GENERATORS or (ANY, generator[1], generator[2]) in KNOWN_GENERATORS

def is_known_feature(cat, key, val):
    vals = KNOWN_FEATURES.get(cat, {}).get(key, [])
    return vals is ANY or val in vals

def is_known_metadata(cat, key, val):
    vals = KNOWN_METADATA.get(cat, {}).get(key, [])
    return vals is ANY or val in vals

def is_known_aux_metadata(key, val):
    vals = KNOWN_AUXILIARY_METADATA.get(key, [])
    return vals is ANY or val in vals

